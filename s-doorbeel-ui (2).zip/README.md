# 🔔 S-Doorbell - Timbre Digital Inteligente

Sistema de timbre inteligente basado en QR para control total de visitas en tu hogar.

![S-Doorbell](./public/images/logo017.png)

## 🎯 Características

- ✅ **QR único permanente** - Un solo código para toda la vida
- ✅ **Sin app para visitantes** - Solo escanean el QR
- ✅ **Control total** - Decidís qué hacer con cada visita
- ✅ **Ubicación opcional** - Pedí ubicación antes de atender
- ✅ **Bloqueo inteligente** - Bloqueá visitantes no deseados
- ✅ **Historial completo** - Todas las visitas registradas
- ✅ **Modo No Molestar** - Desactivá notificaciones cuando quieras
- ✅ **Mobile-first** - Diseñado para usar desde el celular

## 🚀 Inicio Rápido

Ver [INSTALACION.md](./INSTALACION.md) para instrucciones detalladas paso a paso.

```bash
# Instalar dependencias
npm install

# Ejecutar en desarrollo
npm run dev

# Abrir http://localhost:3000
```

## 🏗️ Stack Tecnológico

- **Framework**: Next.js 16 (App Router)
- **UI**: Tailwind CSS v4
- **Componentes**: shadcn/ui
- **Iconos**: Heroicons
- **Lenguaje**: TypeScript
- **Deploy**: Vercel

## 📱 Flujo de Usuario

### Para el Dueño:
1. Iniciás sesión en la app
2. Configurás tu perfil (nombre, dirección, foto)
3. Descargás tu QR único
4. Lo colocás en la entrada de tu casa
5. Cuando alguien escanea, recibís una notificación
6. Decidís: pedir ubicación, cortar o bloquear

### Para el Visitante:
1. Escanea el QR en la puerta
2. Espera respuesta (sin instalar nada)
3. Si el dueño pide ubicación, la comparte
4. Recibe confirmación o rechazo

## 🎨 Componentes

Todos los componentes son reutilizables y modulares:

- **Layout**: `AppLayout`, `Header`, `BottomNavigation`
- **Acciones**: `VisitActions`, `PrimaryButton`
- **Visualización**: `VisitAlertCard`, `StatusBadge`, `QRCodeCard`
- **Formularios**: `HomeProfileForm`, `SecuritySettings`
- **Listas**: `VisitHistoryList`, `BlockedVisitorsList`

## 📄 Licencia

Este proyecto fue creado para uso comercial.

---

**Desarrollado con ❤️ usando v0 by Vercel**
