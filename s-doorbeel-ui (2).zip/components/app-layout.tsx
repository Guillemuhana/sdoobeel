"use client"

import type { ReactNode } from "react"
import { Header } from "./header"
import { BottomNavigation } from "./bottom-navigation"

interface AppLayoutProps {
  children: ReactNode
  showBottomNav?: boolean
}

export function AppLayout({ children, showBottomNav = true }: AppLayoutProps) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <main className="flex-1 pb-20">{children}</main>
      {showBottomNav && <BottomNavigation />}
    </div>
  )
}
