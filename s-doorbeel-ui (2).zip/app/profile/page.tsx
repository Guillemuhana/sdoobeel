"use client"

import { AppLayout } from "@/components/app-layout"
import { HomeProfileForm } from "@/components/home-profile-form"
import { FacadePhotoUploader } from "@/components/facade-photo-uploader"

export default function ProfilePage() {
  const handleSaveProfile = (data: any) => {
    console.log("Saving profile:", data)
    // TODO: Implement actual save
  }

  const handleUploadPhoto = (file: File) => {
    console.log("Uploading photo:", file)
    // TODO: Implement actual upload
  }

  return (
    <AppLayout>
      <div className="container mx-auto space-y-6 p-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Mi Perfil</h1>
          <p className="text-sm text-muted-foreground">Configurá la información de tu hogar</p>
        </div>

        <HomeProfileForm
          initialData={{
            familyName: "Familia González",
            address: "Calle Principal 123",
            neighborhood: "Centro",
            city: "Buenos Aires",
          }}
          onSave={handleSaveProfile}
        />

        <FacadePhotoUploader onUpload={handleUploadPhoto} />
      </div>
    </AppLayout>
  )
}
