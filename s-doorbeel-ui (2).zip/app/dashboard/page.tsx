"use client"

import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { VisitAlertCard } from "@/components/visit-alert-card"
import { Card } from "@/components/ui/card"
import { BellIcon, ClockIcon, ShieldCheckIcon } from "@heroicons/react/24/outline"

export default function DashboardPage() {
  const router = useRouter()

  // Mock data - replace with real data
  const hasActiveVisit = true
  const todayVisitsCount = 3

  return (
    <AppLayout>
      <div className="container mx-auto space-y-6 p-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Inicio</h1>
          <p className="text-sm text-muted-foreground">Familia González</p>
        </div>

        {hasActiveVisit && (
          <VisitAlertCard time="Hace 2 minutos" status="waiting" onClick={() => router.push("/visit/active")} />
        )}

        <div className="grid gap-4 sm:grid-cols-3">
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-blue-100 p-3">
                <BellIcon className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{todayVisitsCount}</p>
                <p className="text-sm text-muted-foreground">Visitas hoy</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-green-100 p-3">
                <ShieldCheckIcon className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">Activo</p>
                <p className="text-sm text-muted-foreground">Sistema</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-amber-100 p-3">
                <ClockIcon className="h-6 w-6 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">50m</p>
                <p className="text-sm text-muted-foreground">Radio seguridad</p>
              </div>
            </div>
          </Card>
        </div>

        <Card className="p-6">
          <h2 className="mb-4 text-lg font-semibold text-foreground">Accesos rápidos</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <button
              onClick={() => router.push("/qr")}
              className="rounded-lg border border-border bg-card p-4 text-left transition-all hover:border-primary hover:shadow-md"
            >
              <p className="font-semibold text-foreground">Ver mi QR</p>
              <p className="text-sm text-muted-foreground">Descargar o imprimir</p>
            </button>
            <button
              onClick={() => router.push("/security")}
              className="rounded-lg border border-border bg-card p-4 text-left transition-all hover:border-primary hover:shadow-md"
            >
              <p className="font-semibold text-foreground">Configurar seguridad</p>
              <p className="text-sm text-muted-foreground">Radio y ubicación</p>
            </button>
          </div>
        </Card>
      </div>
    </AppLayout>
  )
}
