"use client"

import { useState } from "react"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { StatusBadge } from "@/components/status-badge"
import { MapPinIcon } from "@heroicons/react/24/outline"
import { PrimaryButton } from "@/components/primary-button"

export default function VisitorPage() {
  const [status, setStatus] = useState<"waiting" | "location-required" | "ended" | "blocked">("waiting")
  const [locationShared, setLocationShared] = useState(false)

  const handleShareLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          console.log("Location:", position.coords)
          setLocationShared(true)
          // TODO: Send location to backend
        },
        (error) => {
          alert("No se pudo obtener tu ubicación")
        },
      )
    }
  }

  const getMessage = () => {
    switch (status) {
      case "waiting":
        return {
          title: "Esperando respuesta",
          description: "El dueño fue notificado de tu presencia. Por favor aguardá.",
        }
      case "location-required":
        return {
          title: "Ubicación requerida",
          description: "El dueño solicita que compartas tu ubicación antes de continuar.",
        }
      case "ended":
        return {
          title: "Visita finalizada",
          description: "El dueño ha finalizado esta visita. Gracias por tu paciencia.",
        }
      case "blocked":
        return {
          title: "Acceso bloqueado",
          description: "No podés tocar el timbre desde esta ubicación.",
        }
    }
  }

  const message = getMessage()

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/10 to-background p-4">
      <Card className="w-full max-w-md p-8">
        <div className="mb-8 text-center">
          <Image src="/images/logo017.png" alt="S-Doorbell" width={80} height={80} className="mx-auto mb-4" />
          <StatusBadge status={status} className="mb-4" />
        </div>

        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold text-foreground">{message.title}</h1>
          <p className="mt-2 text-sm text-muted-foreground">{message.description}</p>
        </div>

        {status === "location-required" && !locationShared && (
          <PrimaryButton variant="warning" size="lg" className="w-full" onClick={handleShareLocation}>
            <MapPinIcon className="h-5 w-5" />
            Compartir mi ubicación
          </PrimaryButton>
        )}

        {locationShared && (
          <div className="rounded-lg bg-green-50 p-4 text-center">
            <p className="text-sm font-semibold text-green-800">✓ Ubicación compartida</p>
            <p className="mt-1 text-xs text-green-600">Esperando respuesta del dueño</p>
          </div>
        )}
      </Card>
    </div>
  )
}
