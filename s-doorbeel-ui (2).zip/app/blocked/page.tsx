"use client"

import { AppLayout } from "@/components/app-layout"
import { BlockedVisitorsList } from "@/components/blocked-visitors-list"

export default function BlockedPage() {
  // Mock data - replace with real data
  const blockedVisitors = [
    {
      id: "1",
      ip: "192.168.xxx.xxx",
      blockedDate: "24 Dic 2024, 14:30",
      reason: "Visitante sospechoso",
    },
    {
      id: "2",
      ip: "10.0.xxx.xxx",
      blockedDate: "20 Dic 2024, 18:15",
      reason: "Múltiples intentos rechazados",
    },
  ]

  const handleUnblock = (id: string) => {
    console.log("Unblocking visitor:", id)
    // TODO: Implement actual unblock
  }

  return (
    <AppLayout>
      <div className="container mx-auto space-y-6 p-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Visitantes bloqueados</h1>
          <p className="text-sm text-muted-foreground">Personas que no pueden tocar tu timbre</p>
        </div>

        <BlockedVisitorsList visitors={blockedVisitors} onUnblock={handleUnblock} />
      </div>
    </AppLayout>
  )
}
