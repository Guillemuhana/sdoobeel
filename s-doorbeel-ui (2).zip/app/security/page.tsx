"use client"

import { AppLayout } from "@/components/app-layout"
import { SecuritySettings } from "@/components/security-settings"

export default function SecurityPage() {
  const handleSettingsChange = (settings: any) => {
    console.log("Settings changed:", settings)
    // TODO: Implement actual save
  }

  return (
    <AppLayout>
      <div className="container mx-auto space-y-6 p-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Seguridad</h1>
          <p className="text-sm text-muted-foreground">Configurá las opciones de seguridad de tu timbre</p>
        </div>

        <SecuritySettings
          requireLocation={false}
          securityRadius={50}
          doNotDisturb={false}
          onChange={handleSettingsChange}
        />
      </div>
    </AppLayout>
  )
}
