"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { VisitAlertCard } from "@/components/visit-alert-card"
import { VisitActions } from "@/components/visit-actions"

export default function ActiveVisitPage() {
  const router = useRouter()
  const [visitStatus, setVisitStatus] = useState<"waiting" | "location-required" | "ended" | "blocked">("waiting")

  const handleRequestLocation = () => {
    setVisitStatus("location-required")
    // TODO: Implement actual location request
  }

  const handleEndVisit = () => {
    setVisitStatus("ended")
    setTimeout(() => {
      router.push("/dashboard")
    }, 1500)
  }

  const handleBlockVisitor = () => {
    setVisitStatus("blocked")
    setTimeout(() => {
      router.push("/blocked")
    }, 1500)
  }

  return (
    <AppLayout>
      <div className="container mx-auto space-y-6 p-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Visita activa</h1>
          <p className="text-sm text-muted-foreground">Decidí qué hacer con esta visita</p>
        </div>

        <VisitAlertCard time="Hace 2 minutos" status={visitStatus} />

        <VisitActions
          onRequestLocation={handleRequestLocation}
          onEndVisit={handleEndVisit}
          onBlockVisitor={handleBlockVisitor}
          disabled={visitStatus === "ended" || visitStatus === "blocked"}
        />
      </div>
    </AppLayout>
  )
}
