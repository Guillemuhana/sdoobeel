"use client"

import { AppLayout } from "@/components/app-layout"
import { QRCodeCard } from "@/components/qr-code-card"

export default function QRPage() {
  const handleDownloadPNG = () => {
    console.log("Downloading PNG")
    // TODO: Implement actual download
  }

  const handleDownloadPDF = () => {
    console.log("Downloading PDF")
    // TODO: Implement actual download
  }

  return (
    <AppLayout>
      <div className="container mx-auto space-y-6 p-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Tu código QR</h1>
          <p className="text-sm text-muted-foreground">Colocá este QR en la entrada de tu casa</p>
        </div>

        <QRCodeCard
          qrCodeUrl="/images/trsdfhb6.png"
          onDownloadPNG={handleDownloadPNG}
          onDownloadPDF={handleDownloadPDF}
        />
      </div>
    </AppLayout>
  )
}
